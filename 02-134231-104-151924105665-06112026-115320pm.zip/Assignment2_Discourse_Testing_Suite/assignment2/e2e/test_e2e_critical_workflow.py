"""E2E-01 - Critical workflow  |  Shared responsibility of all three members

Workflow retained from Assignment 1:
    sign up  ->  activate by e-mail  ->  log in  ->  create a topic in a category
             ->  receive a reply  ->  see the reply notification

Each member contributed their module's steps through the shared helpers in
utils/pw.py (Module A: signup/login, Module B: topic/reply, Module C: session
state), which is the reuse the demonstration must cite.

Tool: Playwright (two independent browser contexts, one per user).
"""
import pytest
from playwright.sync_api import expect

import config
from utils import data, mailbox
from utils.pw import DiscourseUI


@pytest.mark.e2e
def test_e2e_01_registration_to_reply_notification(browser):
    new_user = data.valid_account("qae2e")
    topic = data.valid_topic()
    reply_body = data.valid_reply()

    # ---- Step 1: registration (Module A, Daniyal) ---------------------------
    user_ctx = browser.new_context(viewport={"width": 1440, "height": 900})
    user_page = user_ctx.new_page()
    user_page.set_default_timeout(config.DEFAULT_TIMEOUT_MS)
    user_ui = DiscourseUI(user_page)

    user_ui.signup(new_user["username"], new_user["email"], new_user["password"])
    user_page.screenshot(path=f"{config.EVIDENCE_DIR}/E2E-01_step1_registered.png")
    expect(user_page.locator("body")).to_contain_text(new_user["email"])
    assert not user_ui.logged_in(), "A new account must be inactive until the e-mail is confirmed"

    # ---- Step 2: e-mail activation -----------------------------------------
    link = mailbox.activation_link(new_user["email"])
    user_page.goto(link, wait_until="domcontentloaded")
    # Discourse asks for one explicit confirmation click on the activation page.
    confirm = user_page.locator(".activate-account-button")
    confirm.first.wait_for(state="visible", timeout=15000)
    user_page.wait_for_timeout(800)
    confirm.first.click()
    user_page.wait_for_timeout(6000)
    user_page.screenshot(path=f"{config.EVIDENCE_DIR}/E2E-01_step2_activated.png")
    activation_text = user_page.locator("body").inner_text().lower()
    assert "click here to activate your account" not in activation_text, (
        "The activation link must not leave the account waiting for confirmation, "
        f"page showed: {activation_text[:300]!r}"
    )

    # ---- Step 3: login (Module A) ------------------------------------------
    user_ui.login(new_user["username"], new_user["password"])
    assert user_ui.logged_in(), "The activated account must be able to log in"

    # ---- Step 4: create a topic (Module B, Raza) ---------------------------
    # NOTE (recorded as defect D-02 in docs/DEFECTS.md): on this instance the very
    # first post of a brand-new account is enqueued for moderation, so the posting
    # leg of the workflow is executed with a seeded member account. The new account
    # still completes registration, activation and login above.
    member_ctx = browser.new_context(viewport={"width": 1440, "height": 900})
    member_page = member_ctx.new_page()
    member_page.set_default_timeout(config.DEFAULT_TIMEOUT_MS)
    member_ui = DiscourseUI(member_page)
    member_ui.login(config.USERS["raza"], config.FIXTURE_PASSWORD)
    member_ui.open_new_topic()
    member_ui.fill_topic(topic["title"], topic["body"], config.CATEGORY_NAME)
    member_ui.submit_topic()
    member_page.wait_for_url("**/t/**", timeout=config.DEFAULT_TIMEOUT_MS)
    topic_url = member_page.url
    topic_id = topic_url.rstrip("/").split("/")[-1]
    member_page.screenshot(path=f"{config.EVIDENCE_DIR}/E2E-01_step4_topic_created.png")
    expect(member_page.locator(".topic-post").first).to_be_visible()

    # ---- Step 5: second user replies (Module B) ---------------------------
    other_ctx = browser.new_context(viewport={"width": 1440, "height": 900})
    other_page = other_ctx.new_page()
    other_page.set_default_timeout(config.DEFAULT_TIMEOUT_MS)
    other_ui = DiscourseUI(other_page)
    other_ui.login(config.USERS["daniyal"], config.FIXTURE_PASSWORD)
    other_ui.open_topic(topic_id)
    before = other_page.locator(".topic-post").count()
    other_ui.reply(reply_body)
    try:
        other_page.wait_for_function(
            "n => document.querySelectorAll('.topic-post').length > n", arg=before, timeout=15000
        )
    except Exception:
        pass
    after = other_page.locator(".topic-post").count()
    if after == before:
        other_page.reload(wait_until="domcontentloaded")
        other_page.wait_for_timeout(2500)
        after = other_page.locator(".topic-post").count()
    other_page.screenshot(path=f"{config.EVIDENCE_DIR}/E2E-01_step5_reply.png")
    assert after == before + 1, "The second user's reply must be appended to the topic"

    # ---- Step 6: owner sees the notification (Module C session state) -----
    member_page.goto(f"{config.BASE_URL}/u/{config.USERS['raza']}/notifications",
                     wait_until="domcontentloaded")
    member_page.wait_for_timeout(2500)
    notif_text = member_page.locator("#main-outlet").inner_text()
    member_page.screenshot(path=f"{config.EVIDENCE_DIR}/E2E-01_step6_notification.png")
    assert config.USERS["daniyal"] in notif_text or "replied" in notif_text.lower(), (
        "The topic owner must receive a reply notification at the end of the workflow, "
        f"notifications page showed: {notif_text[:300]!r}"
    )

    other_ctx.close()
    member_ctx.close()
    user_ctx.close()
