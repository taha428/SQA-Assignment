"""Minimal SMTP capture server used by the E2E test to read Discourse activation mail."""
import asyncio, email, os, sys, time
from email import policy
from aiosmtpd.controller import Controller

OUT = os.environ.get("MAIL_SINK_DIR", "/tmp/qa_mailbox")
os.makedirs(OUT, exist_ok=True)


class Handler:
    async def handle_DATA(self, server, session, envelope):
        msg = email.message_from_bytes(envelope.content, policy=policy.default)
        name = f"{int(time.time()*1000)}-{abs(hash(str(msg['To'])))}.eml"
        with open(os.path.join(OUT, name), "wb") as fh:
            fh.write(envelope.content)
        print("captured", msg["To"], msg["Subject"], flush=True)
        return "250 Message accepted for delivery"


if __name__ == "__main__":
    Controller(Handler(), hostname="127.0.0.1", port=1025).start()
    print("SMTP sink on 127.0.0.1:1025 ->", OUT, flush=True)
    asyncio.get_event_loop().run_forever()
