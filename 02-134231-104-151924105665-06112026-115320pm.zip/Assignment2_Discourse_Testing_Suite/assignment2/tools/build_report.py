import base64, json, os, subprocess

imgs = json.load(open("/tmp/imgs.json"))
def img(key, cap):
    if not imgs.get(key): return ""
    return f'<figure><img src="data:image/png;base64,{imgs[key]}"/><figcaption>{cap}</figcaption></figure>'

CSS = """
@page { size: A4; margin: 16mm 14mm 14mm 14mm; }
* { box-sizing: border-box; }
body { font-family: "Inter", "DejaVu Sans", Arial, sans-serif; font-size: 9.6pt; line-height: 1.45; color: #1d2125; margin:0; }
h1 { font-size: 22pt; margin: 0 0 4px; letter-spacing: -0.5px; }
h2 { font-size: 13pt; margin: 20px 0 6px; padding-bottom: 3px; border-bottom: 2px solid #0d6efd; color:#0d3b66; }
h3 { font-size: 10.5pt; margin: 14px 0 4px; color:#0d3b66; }
p, li { margin: 4px 0; }
table { width: 100%; border-collapse: collapse; margin: 6px 0 10px; font-size: 8.4pt; }
th { background: #0d3b66; color: #fff; text-align: left; padding: 4px 5px; font-weight: 600; }
td { border-bottom: 1px solid #dfe3e8; padding: 3.5px 5px; vertical-align: top; }
tr:nth-child(even) td { background: #f7f9fb; }
.pass { color: #1a7f37; font-weight: 700; }
.fail { color: #b42318; font-weight: 700; }
.cover { height: 250mm; display: flex; flex-direction: column; justify-content: center; }
.cover .kicker { text-transform: uppercase; letter-spacing: 2px; font-size: 9pt; color: #0d6efd; font-weight: 700; }
.cover .sub { font-size: 12pt; color: #444; margin-top: 6px; }
.meta { margin-top: 28px; font-size: 9.5pt; }
.meta td { border: none; padding: 2px 8px 2px 0; }
.box { background:#f1f6fc; border-left: 4px solid #0d6efd; padding: 8px 10px; margin: 8px 0; font-size: 9pt; }
.warn { background:#fff4e5; border-left-color:#e8890c; }
.danger { background:#fdf2f2; border-left-color:#b42318; }
figure { margin: 6px 0 10px; page-break-inside: avoid; }
img { width: 100%; max-height: 95mm; object-fit: cover; object-position: top; border: 1px solid #ccd3db; border-radius: 3px; }
figcaption { font-size: 7.8pt; color: #5b6673; margin-top: 2px; }
.pagebreak { page-break-before: always; }
.two { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
code { font-family: "DejaVu Sans Mono", monospace; font-size: 8.2pt; background:#eef1f4; padding:0 3px; }
.small { font-size: 8.2pt; color:#5b6673; }
"""

HTML = f"""<!doctype html><html><head><meta charset="utf-8"><style>{CSS}</style></head><body>

<section class="cover">
  <div class="kicker">Software Quality Assurance &nbsp;·&nbsp; Assignment 2</div>
  <h1>Automated Testing of Discourse</h1>
  <div class="sub">Continuation of the Assignment 1 review: 12 functional cases,<br/>3 non-functional checks and one end-to-end critical workflow</div>
  <table class="meta">
    <tr><td><b>Application</b></td><td>Discourse 3.4.0 — open source community platform (GPL v2)</td></tr>
    <tr><td><b>Source</b></td><td>https://github.com/discourse/discourse (tag v3.4.0)</td></tr>
    <tr><td><b>Tested version</b></td><td>commit 43eab83d · local development instance</td></tr>
    <tr><td><b>Tools</b></td><td>Playwright 1.56 (Chromium), Selenium WebDriver 4.52, pytest 8.4, psql, Python requests</td></tr>
    <tr><td><b>Environment</b></td><td>Ubuntu 24.04, PostgreSQL 16, Redis 7, Ruby 3.2.3, Rails 7.2, Node 22</td></tr>
  </table>
  <table class="meta" style="margin-top:22px">
    <tr><th style="background:#0d3b66;color:#fff">Member</th><th style="background:#0d3b66;color:#fff">Enrollment</th><th style="background:#0d3b66;color:#fff">Module</th><th style="background:#0d3b66;color:#fff">Individual responsibility</th></tr>
    <tr><td>Daniyal Jawed (team lead)</td><td>02-134231-085</td><td>A — Registration &amp; login</td><td>FR-01, FR-02 · 4 cases · NFR-02 · setup instructions · Module A steps in E2E</td></tr>
    <tr><td>Muhammad Raza</td><td>02-134231-099</td><td>B — Topics &amp; posting</td><td>FR-03, FR-04 · 4 cases · NFR-01 · test data &amp; requirement mapping · Module B steps</td></tr>
    <tr><td>Taha Bilal</td><td>02-134231-104</td><td>C — Search &amp; private messages</td><td>FR-05, FR-06 · 4 cases · NFR-03 · suite combination &amp; results · Module C steps</td></tr>
  </table>
</section>

<h2>1. Scope and continuity from Assignment 1</h2>
<p>Assignment 1 classified five functional requirements and three non-functional requirements for
Discourse and recorded five manual quality observations. This assignment keeps every one of them:
the same requirement IDs, the same quality attributes (functionality, usability, security,
performance, reliability) and the same critical workflow — <i>a visitor registers, activates the
account by e-mail, logs in, creates a topic in a category and receives a reply notification</i>.</p>
<table>
<tr><th>Assignment 1</th><th>Assignment 2</th><th>Change</th></tr>
<tr><td>FR-01 … FR-05</td><td>FR-01 … FR-05</td><td>Retained unchanged, still the traceability anchor</td></tr>
<tr><td>—</td><td>FR-06 private message delivery</td><td><b>Added</b> — completes Module C so every member owns two FRs (six in total)</td></tr>
<tr><td>NFR-01 performance, NFR-02 security, NFR-03 usability</td><td>Same three, each now with a measurable pass condition</td><td>Turned from prose targets into executable checks with thresholds</td></tr>
<tr><td>Module list (6 areas)</td><td>3 modules, one per member, using the app's actual areas</td><td>Consolidated for the 12-case allocation</td></tr>
<tr><td>Five manual observations</td><td>Re-used as the hypotheses behind the automated cases</td><td>Observation 3 (password validation) became defect D-01</td></tr>
</table>
<div class="box">The six functional requirements, two per member: <b>FR-01</b> registration with e-mail
activation and <b>FR-02</b> login/logout/password reset (Module A); <b>FR-03</b> create a topic in a
category and <b>FR-04</b> reply/quote/like with owner notification (Module B); <b>FR-05</b> keyword
search with filters and <b>FR-06</b> private message delivery (Module C, FR-06 is the new one).</div>

<h2>2. Requirement-to-test traceability</h2>
<table>
<tr><th>Req.</th><th>Requirement (short)</th><th>Tests</th><th>Owner</th><th>Technique</th><th>Status</th></tr>
<tr><td>FR-01</td><td>Register an account; activation by e-mail required</td><td>TC-A-01, TC-A-02</td><td>Daniyal Jawed</td><td>EP, BVA</td><td class="pass">2/2 pass</td></tr>
<tr><td>FR-02</td><td>Log in, log out, reset a forgotten password</td><td>TC-A-03, TC-A-04</td><td>Daniyal Jawed</td><td>EP</td><td class="pass">2/2 pass</td></tr>
<tr><td>FR-03</td><td>Create a topic in a category with optional tags</td><td>TC-B-01, TC-B-02</td><td>Muhammad Raza</td><td>EP, BVA</td><td class="pass">2/2 pass</td></tr>
<tr><td>FR-04</td><td>Reply, quote, like; notify the topic owner</td><td>TC-B-03, TC-B-04</td><td>Muhammad Raza</td><td>EP</td><td class="pass">2/2 pass</td></tr>
<tr><td>FR-05</td><td>Search topics and posts by keyword, filter results</td><td>TC-C-01, TC-C-02</td><td>Taha Bilal</td><td>EP, BVA</td><td class="pass">2/2 pass</td></tr>
<tr><td>FR-06</td><td>Send a private message delivered to the recipient</td><td>TC-C-03, TC-C-04</td><td>Taha Bilal</td><td>EP</td><td class="pass">2/2 pass</td></tr>
<tr><td>NFR-01</td><td>Topic list usable within about 3 s under normal load</td><td>NFR-01</td><td>Muhammad Raza</td><td>load + browser timing</td><td class="pass">pass</td></tr>
<tr><td>NFR-02</td><td>Password hashing, HTTPS-only, minimum length and complexity</td><td>NFR-02</td><td>Daniyal Jawed</td><td>DB inspection + HTTP</td><td class="fail">fail (D-01)</td></tr>
<tr><td>NFR-03</td><td>Usable on desktop and mobile; core actions without training</td><td>NFR-03</td><td>Taha Bilal</td><td>3 viewports</td><td class="pass">pass</td></tr>
<tr><td colspan="2"><b>Critical workflow</b></td><td>E2E-01</td><td>All members</td><td>end-to-end</td><td class="pass">pass</td></tr>
</table>
<p class="small">Full machine-readable version: <code>data/requirement_mapping.csv</code> (test id,
requirement, owner, inputs, expected result, status).</p>

<h2>3. Test design — equivalence partitioning and boundary value analysis</h2>
<p>Each member applies both techniques and labels every case. Partitions were derived from the
inputs the requirement names; boundary values come from the site settings that implement each rule
(minimum password length, minimum topic title length, minimum search term length).</p>
<table>
<tr><th>Case</th><th>Input</th><th>Partition / boundary</th><th>Technique</th><th>Expected</th></tr>
<tr><td>TC-A-01</td><td>username 8–20, valid e-mail, 12-char password</td><td>valid partition of (username, email, password)</td><td>EP</td><td>Account created, confirmation page, activation mail</td></tr>
<tr><td>TC-A-02</td><td>password 9 / 10 (min−1 / min)</td><td>boundary at <code>min_password_length</code></td><td>BVA</td><td>9 rejected with a length message, 10 accepted</td></tr>
<tr><td>TC-A-03</td><td>existing account, correct password</td><td>valid credential partition</td><td>EP</td><td>Session, current-user menu, HttpOnly cookie</td></tr>
<tr><td>TC-A-04</td><td>wrong password / unknown username</td><td>two invalid credential partitions</td><td>EP</td><td>Both refused, no session, generic error</td></tr>
<tr><td>TC-B-01</td><td>unique 55-char title, body 130 chars, category</td><td>valid topic partition</td><td>EP</td><td>Topic created, listed in the category</td></tr>
<tr><td>TC-B-02</td><td>title 14 / 15 (min−1 / min)</td><td>boundary at <code>min_topic_title_length</code></td><td>BVA</td><td>14 blocked, 15 accepted</td></tr>
<tr><td>TC-B-03</td><td>reply by a second user</td><td>valid reply partition</td><td>EP</td><td>Post count +1, owner notification</td></tr>
<tr><td>TC-B-04</td><td>empty body</td><td>invalid (empty) partition</td><td>EP</td><td>No post added</td></tr>
<tr><td>TC-C-01</td><td>keyword <code>ZQX2026</code></td><td>valid keyword partition</td><td>EP</td><td>≥ 1 result, result links to the topic</td></tr>
<tr><td>TC-C-02</td><td>query 2 / 3 chars</td><td>boundary at <code>min_search_term_length</code></td><td>BVA</td><td>2 → no results, 3 → matching topic</td></tr>
<tr><td>TC-C-03</td><td>PM to an existing user</td><td>valid message partition</td><td>EP</td><td>Message in Sent and in the recipient Inbox</td></tr>
<tr><td>TC-C-04</td><td>PM to <code>no_such_user_99</code></td><td>invalid recipient partition</td><td>EP</td><td>Send blocked, no message created</td></tr>
</table>

<h3>Assertions</h3>
<p>Every case asserts the observable outcome, not the click: post counts, presence of the generated
text, the category badge, the notification entry, the session cookie flags, the number of search
results, HTTP status codes and the password hash metadata. A case only passes when the assertion
holds; screenshots are attached per case (<code>evidence/</code>).</p>

<h2>4. Execution</h2>
<h3>4.1 Smoke subset first</h3>
<p>One critical case per module runs first, so a broken build is caught in under a minute:
<b>TC-A-03</b> (login), <b>TC-B-01</b> (create topic), <b>TC-C-01</b> (search). Command:
<code>pytest -m smoke</code>. Smoke cases are part of the twelve functional cases, not extra.</p>
<h3>4.2 Full run</h3>
<table>
<tr><th>Suite</th><th>Checks</th><th>Passed</th><th>Failed</th><th>Blocked</th><th>Time</th></tr>
<tr><td>Smoke (3 cases)</td><td>3</td><td class="pass">3</td><td>0</td><td>0</td><td>~35 s</td></tr>
<tr><td>Module A — registration &amp; login (Selenium + Playwright)</td><td>4</td><td class="pass">4</td><td>0</td><td>0</td><td>~36 s</td></tr>
<tr><td>Module B — topics &amp; posting (Playwright)</td><td>4</td><td class="pass">4</td><td>0</td><td>0</td><td>~75 s</td></tr>
<tr><td>Module C — search &amp; PM (Playwright + Selenium cross-check)</td><td>4 (+1)</td><td class="pass">4</td><td>0</td><td>0</td><td>~79 s</td></tr>
<tr><td>NFR checks</td><td>3</td><td class="pass">2</td><td class="fail">1 (NFR-02 → D-01)</td><td>0</td><td>~90 s</td></tr>
<tr><td>End-to-end</td><td>1</td><td class="pass">1</td><td>0</td><td>0</td><td>~40 s</td></tr>
<tr><td><b>Total</b></td><td><b>16</b></td><td class="pass">15</td><td class="fail">1</td><td>0</td><td>~6 min</td></tr>
</table>
<div class="box warn">The failing check is a <b>finding, not a broken script</b>: the JSON sign-up
endpoint accepts a password below <code>min_password_length</code> although the UI rejects it
(defect D-01). The check therefore stays red until the product is fixed, which is the intended
behaviour of a security gate.</div>
<div class="box small">Environment note for reproduction: Discourse rate-limits account creation,
topic creation, private messages and logins per IP. The suite raises those limits on the local
instance (<code>tools/apply_test_settings.rb</code>) and resets the limiter with
<code>redis-cli flushdb</code> before a full run; without that reset a repeated run produces
"creating topics a bit too quickly" instead of test results.</div>

{img("signup","TC-A-01 — valid registration lands on the confirmation page that names the e-mail address")}
{img("bva","TC-A-02 — boundary value below the minimum password length is rejected inline")}

<div class="pagebreak"></div>
<h3>4.3 Selected evidence</h3>
<div class="two">
{img("topic","TC-B-01 — topic created in the QA Automation category")}
{img("search","TC-C-01 — keyword search returns the seeded topic")}
</div>
{img("pm","TC-C-03 — sent private message listed in the sender's Sent folder")}
{img("e2e","E2E-01 — the topic owner sees the reply notification at the end of the workflow")}

<h2>5. Non-functional checks</h2>
<table>
<tr><th>Check</th><th>Metric</th><th>Threshold</th><th>Conditions</th><th>Measured</th><th>Verdict</th></tr>
<tr><td>NFR-01<br/>Performance</td><td>p95 latency of <code>GET /latest.json</code>; browser DOMContentLoaded</td><td>p95 ≤ 3000 ms, error rate ≤ 1 %</td><td>5 concurrent users, 30 s, local instance, 3-request warm-up</td><td>p95 <b>586 ms</b>, p50 250 ms, 0 errors, DCL <b>1.19 s</b>, load 1.69 s</td><td class="pass">PASS</td></tr>
<tr><td>NFR-02<br/>Security</td><td>(a) storage: PBKDF2-SHA256 + iterations<br/>(b) session cookie flags<br/>(c) server-side minimum length</td><td>100 % of sampled accounts; HttpOnly + SameSite=Lax; 9-char password rejected</td><td>DB read on 3 accounts; one HTTP login; one JSON sign-up</td><td>(a) <code>$pbkdf2-sha256$i=600000,l=32$</code> on 3/3<br/>(b) HttpOnly, SameSite=Lax<br/>(c) <b>accepted</b> (HTTP 200)</td><td class="fail">FAIL (D-01)</td></tr>
<tr><td>NFR-03<br/>Usability</td><td>horizontal overflow, control visibility, tap target, core action</td><td>overflow ≤ 2 px; all controls visible; target ≥ 32 px; core action completes</td><td>360×800, 768×1024, 1440×900, one session per viewport</td><td>0 px overflow at all three; header, search and sidebar toggle visible; 44 px search target; composer reachable</td><td class="pass">PASS</td></tr>
</table>
{img("mobile","NFR-03 — 360×800 mobile viewport with no horizontal overflow")}
<p class="small">NFR-01 contradicts the Assignment 1 manual measurement (6.70 s on a hosted trial
instance). The difference is explained by the environment: the local instance has no CDN, no
external scripts and a warm cache, so the automated number measures server rendering rather than a
cold public network. Both results are reported as measured.</p>

<h2>6. Defects</h2>
<table>
<tr><th>ID</th><th>Defect</th><th>Severity</th><th>Expected</th><th>Actual</th><th>Evidence</th></tr>
<tr><td>D-01</td><td>JSON sign-up endpoint bypasses the password policy</td><td class="fail">High</td><td>9-char password rejected (HTTP 4xx)</td><td>HTTP 200 <code>success:true</code>, account created (a 3-char password is accepted too)</td><td><code>reports/nfr02_security.json</code>, <code>reports/http_trace_signup_weak_password.txt</code></td></tr>
<tr><td>D-02</td><td>First post of a new account is queued silently for moderation</td><td>Medium</td><td>Topic opens with the post visible</td><td><code>{{"action":"enqueued","pending_count":1}}</code>, composer closes with no message</td><td>E2E trace; see <code>docs/defects.md</code></td></tr>
</table>
<p>Script errors were kept separate from application defects and are listed in
<code>docs/defects.md</code> (Selenium click on the new sign-up component, duplicate-content 422,
rate limiting 429, similar-topic dialog). No defect was reported without a reproduction, and the
one genuine failure above is reported as failing rather than retried until green.</p>

<h2>7. Documented change and regression</h2>
<p><b>R-01 — security hardening.</b> <code>min_password_length</code> was raised from 10 to 12 on the
test instance and the boundary case derives both values from the setting, so it proves the new
policy without being rewritten. A server-side length check was also added to
<code>UsersController#create</code> (<code>patches/0001-password-policy.patch</code>) to close D-01.</p>
<table>
<tr><th>Stage</th><th>Case</th><th>Input</th><th>Result</th></tr>
<tr><td>Before (min = 10)</td><td>TC-A-02</td><td>9-char password / 10-char password</td><td class="pass">9 rejected, 10 accepted</td></tr>
<tr><td>Change</td><td>R-01</td><td><code>SiteSetting.min_password_length = 12</code> + controller patch</td><td>applied to the local instance</td></tr>
<tr><td>After (min = 12)</td><td>TC-A-02</td><td>11-char password / 12-char password</td><td class="pass">11 rejected, 12 accepted</td></tr>
<tr><td>After (min = 12)</td><td>TC-A-03 (smoke)</td><td>valid login</td><td class="pass">pass — authentication unaffected</td></tr>
</table>
<p class="small">Honest note: the controller patch is committed in the ZIP but the confirmation run
against the running development server still returned <code>success:true</code> for a short password,
so D-01 stays <b>open</b> and its confirmation is reported as inconclusive rather than as fixed.
The configuration change (minimum length) is verified by the passing boundary case and is what the
before/after table documents.</p>

<h2>8. Reproduction</h2>
<p>The ZIP contains the scripts, the test data generators, the fixture seeder, the site-setting
script, the SMTP capture tool, the raw execution reports (JUnit XML + JSON), the HTML report, all
screenshots and the patch. <code>RUN_INSTRUCTIONS.md</code> lists the exact commands, including the
environment variables (<code>DISCOURSE_BASE_URL</code>, <code>MAIL_SINK_DIR</code>).</p>
<table>
<tr><th>Folder</th><th>Contents</th></tr>
<tr><td><code>tests/</code></td><td>12 functional cases — Module A (Selenium + Playwright), B, C (Playwright + Selenium cross-check)</td></tr>
<tr><td><code>nfr/</code></td><td>NFR-01 load and browser timing, NFR-02 storage/cookie/policy, NFR-03 three viewports</td></tr>
<tr><td><code>e2e/</code></td><td>registration → activation → login → topic → reply → notification</td></tr>
<tr><td><code>utils/</code></td><td>shared page helpers, Selenium driver, test-data builders, mailbox reader</td></tr>
<tr><td><code>data/</code>, <code>reports/</code>, <code>evidence/</code></td><td>requirement mapping, raw results, screenshots</td></tr>
<tr><td><code>tools/</code></td><td>fixtures, settings, SMTP sink, this report generator</td></tr>
</table>

<h2>9. Demonstration plan (5 minutes)</h2>
<table>
<tr><th>Time</th><th>Member</th><th>Demonstrates</th><th>Assertion shown</th></tr>
<tr><td>0:00–0:40</td><td>Daniyal Jawed</td><td>TC-A-02 boundary case (live run)</td><td>Short password rejected inline; boundary password creates the account</td></tr>
<tr><td>0:40–1:20</td><td>Muhammad Raza</td><td>TC-B-01 topic creation</td><td>Topic title, category badge and listing asserted</td></tr>
<tr><td>1:20–2:00</td><td>Taha Bilal</td><td>TC-C-02 search boundary</td><td>2-char query returns nothing, 3-char query returns the topic</td></tr>
<tr><td>2:00–3:00</td><td>All</td><td>E2E-01 live</td><td>Notification appears for the topic owner</td></tr>
<tr><td>3:00–4:00</td><td>Daniyal / Raza</td><td>NFR-02 and NFR-01 reports</td><td>PBKDF2 600k iterations; p95 586 ms against a 3 s threshold</td></tr>
<tr><td>4:00–5:00</td><td>Taha</td><td>Defects and regression</td><td>D-01 accepted weak password; before/after boundary run</td></tr>
</table>
<p class="small">Reused code to cite during the demo: <code>utils/pw.py</code> (<code>login</code>,
<code>open_new_topic</code>, <code>submit_topic</code>, <code>reply</code>, <code>search</code>) is
imported by Module B, Module C and the end-to-end test; <code>utils/data.py</code> supplies the same
partition and boundary values to all twelve cases.</p>

</body></html>"""

open("reports/report.html","w").write(HTML)
subprocess.run(["google-chrome","--headless","--disable-gpu","--no-sandbox",
                "--print-to-pdf=reports/Assignment2_Discourse_Automated_Testing.pdf",
                "--no-pdf-header-footer","reports/report.html"], check=True,
               capture_output=True)
print("pdf bytes:", os.path.getsize("reports/Assignment2_Discourse_Automated_Testing.pdf"))
