# Seeds the local Discourse test instance with deterministic fixtures.
PW = "Str0ng-Passw0rd!"
USERS = [
  ["admin_qa",    "admin_qa@example.com",    true,  true, 4, "Site Admin"],
  ["daniyal_qa",  "daniyal_qa@example.com",  false, false, 2, "Daniyal (QA)"],
  ["raza_qa",     "raza_qa@example.com",     false, false, 2, "Raza (QA)"],
  ["taha_qa",     "taha_qa@example.com",     false, false, 2, "Taha (QA)"],
  ["maria_qa",    "maria_qa@example.com",    false, false, 2, "Maria (QA)"],
  ["omar_qa",     "omar_qa@example.com",     false, false, 2, "Omar (QA)"],
]
CATEGORIES = [
  ["QA Automation", "qa-automation", "Category used by the automated regression suite"],
  ["Manual Testing", "manual-testing", "Manual review notes and observations"],
]
USERS.each do |username, email, admin, moderator, tl, name|
  u = User.find_by(username: username) || User.new(username: username, email: email)
  u.email = email
  u.name = name
  u.password = PW
  u.active = true
  u.approved = true
  u.admin = admin
  u.moderator = moderator
  u.trust_level = tl
  u.save!
  u.activate if u.respond_to?(:activate)
  EmailToken.where(user_id: u.id).delete_all
  puts "user ok: #{username}"
end
CATEGORIES.each do |name, slug, desc|
  c = Category.find_by(slug: slug) || Category.new
  c.name = name
  c.slug = slug
  c.description = desc
  c.color = "0088CC"
  c.user_id = User.find_by(username: "admin_qa").id
  c.save!
  puts "category ok: #{slug}"
end
# Seed a topic whose title carries a unique search token (FR-05 / TC-C-01)
seeder = User.find_by(username: "raza_qa")
cat = Category.find_by(slug: "qa-automation")
token_title = "Search marker ZQX2026 release readiness checklist"
unless Topic.find_by(title: token_title)
  PostCreator.create!(seeder, title: token_title, raw: "This topic exists so the search suite can find the marker token ZQX2026 inside a real topic. " * 2, category: cat.id)
  puts "topic ok: #{token_title}"
end
puts "fixtures ready"
