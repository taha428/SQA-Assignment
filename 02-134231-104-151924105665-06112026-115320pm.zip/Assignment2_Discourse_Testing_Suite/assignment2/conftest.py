"""Shared pytest fixtures for the Discourse Assignment 2 suite."""
import os

import pytest
from playwright.sync_api import sync_playwright

import config
from utils.pw import DiscourseUI
from utils.selenium_ui import SeleniumUI, make_driver


def pytest_configure(config):
    for marker in [
        "smoke: one critical case per module, run first",
        "functional: the twelve functional cases",
        "nfr: the three measurable non-functional checks",
        "e2e: the shared end-to-end critical workflow",
        "m1: Module A - registration and login (Daniyal Jawed)",
        "m2: Module B - topics and posting (Muhammad Raza)",
        "m3: Module C - search and private messages (Taha Bilal)",
        "regression: re-run of affected cases after the documented change",
    ]:
        config.addinivalue_line("markers", marker)


@pytest.fixture(scope="session")
def browser():
    with sync_playwright() as p:
        b = p.chromium.launch(headless=config.HEADLESS, slow_mo=config.SLOW_MO_MS)
        yield b
        b.close()


@pytest.fixture()
def context(browser):
    ctx = browser.new_context(viewport={"width": 1440, "height": 900})
    yield ctx
    ctx.close()


@pytest.fixture()
def page(context):
    pg = context.new_page()
    pg.set_default_timeout(config.DEFAULT_TIMEOUT_MS)
    yield pg
    pg.close()


@pytest.fixture()
def ui(page) -> DiscourseUI:
    return DiscourseUI(page)


@pytest.fixture()
def driver():
    d = make_driver()
    yield d
    d.quit()


@pytest.fixture()
def sel(driver) -> SeleniumUI:
    return SeleniumUI(driver)


def pytest_runtest_makereport(item, call):
    """Capture a screenshot for every failing test (evidence for the report)."""
    if call.when != "call" or not call.excinfo:
        return
    safe = item.name.replace("[", "_").replace("]", "").replace("/", "_")
    path = os.path.join(config.EVIDENCE_DIR, f"FAIL_{safe}.png")
    page = item.funcargs.get("page")
    driver = item.funcargs.get("driver")
    try:
        if page is not None:
            page.screenshot(path=path)
        elif driver is not None:
            driver.save_screenshot(path)
    except Exception:
        pass
