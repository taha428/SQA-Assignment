# Documented change and regression evidence (R-01)

**Change** - Security hardening of the local environment and of the sign-up API contract:

* Site setting `min_password_length` raised from 10 to 12 on the test instance.
* The automated boundary case TC-A-02 now derives both boundary values from the
  configured minimum (11 characters -> rejected, 12 -> accepted), so the same script
  proves the new policy without editing the test body.
* A server-side length check was added to `UsersController#create`
  (`patches/0001-password-policy.patch`) so the JSON endpoint cannot bypass the policy
  (defect D-01).

**Before** (min = 10)
* `TC-A-02_password_below_boundary.png` - 9-character password rejected by the form,
  10-character password accepted, account created.
* `NFR-02` measurement: `POST /u.json` with a 9-character password returned
  HTTP 200 `success:true` (defect D-01 confirmed).

**After** (min = 12)
* TC-A-02 re-run: 11-character password rejected, 12-character password accepted
  (`TC-A-02_password_at_boundary.png` regenerated).
* Smoke re-run for Module A (TC-A-03 login) passed, confirming the change did not
  break the authentication path.

**Commands**

```bash
# before
pytest tests/test_m1_registration_login.py -k tc_a_02 -q
# change
rails runner 'SiteSetting.min_password_length = 12'
# after (the suite reads the setting from the environment, mirroring the instance)
QA_MIN_PASSWORD_LENGTH=12 pytest tests/test_m1_registration_login.py -k tc_a_02 -q
QA_MIN_PASSWORD_LENGTH=12 pytest -m smoke -q
```

**Result** regression cases pass with the new boundary; no other module was affected
(the policy is only consulted by registration and password change).
