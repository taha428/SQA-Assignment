# Defect log (Assignment 2)

Application: Discourse 3.4.0 (github.com/discourse/discourse, tag v3.4.0)
Instance: local development instance, http://localhost:4200

| ID | Title | Module / Requirement | Severity | Type | Status |
|----|-------|----------------------|----------|------|--------|
| D-01 | Sign-up JSON endpoint accepts passwords shorter than `min_password_length` | A / FR-01, NFR-02 | High (security) | Application defect | Open |
| D-02 | First post of a brand-new account is queued for moderation without a clear UI explanation | B / FR-03, FR-04 | Medium (workflow) | Application behaviour / documentation gap | Open |

## D-01 - Password policy bypass on the JSON sign-up endpoint

**Steps**
1. Sign in as administrator, set `min_password_length = 10` (default).
2. In the browser, open `/signup` and submit a 9-character password -> the form refuses
   with "Your password is too short (minimum is 10 characters)" (TC-A-02, screenshot
   `TC-A-02_password_below_boundary.png`).
3. Send the same payload to the JSON endpoint:
   `POST /u.json` with `password=Ab1xxxxxx` and a valid CSRF token.

**Expected** HTTP 4xx / `success:false` with a length message, no account created.
**Actual** HTTP 200 `{"success":true,...}` - the account is created with a 9-character
password (and even a 3-character password, `abc`), bypassing the rule the UI enforces.
**Severity** High - a client that posts directly to the API can create accounts with
weak credentials, which contradicts NFR-02.
**Evidence** `reports/nfr02_security.json` (`checks.M3_password_policy`), captured
request/response in `reports/http_trace_signup_weak_password.txt`.
**Fix applied locally (regression change R-01)** a server-side minimum length check was
added to `UsersController#create` (patch in `patches/0001-password-policy.patch`).

## D-02 - New account's first post is enqueued for review

**Steps**
1. Register a new account, activate it through the e-mail link, log in.
2. Create a topic from `/new-topic`.
**Expected** the topic opens with the new post visible.
**Actual** the request returns `{"action":"enqueued","success":true,"pending_count":1,...}`
and the post waits in the review queue; the composer closes with no message, so the user
sees nothing happen.
**Severity** Medium - a first-time user believes posting is broken; the critical
workflow (registration -> first post) cannot complete without a moderator.
**Evidence** `E2E-01_step4_topic_created.png` is taken with a seeded member account for this
reason; the enqueued response is quoted in `reports/http_trace_signup_weak_password.txt`.

## Script errors (kept separate from application defects)

| Script error | Cause | Resolution |
|--------------|-------|------------|
| Selenium sign-up submission hung | `WebElement.click()` and JS click do not fire the Ember action of the new multi-step sign-up component in headless Chrome | registration cases moved to Playwright (documented in `docs/tool-comparison.md`) |
| "Password has too many repeated characters" | boundary value used a repeated character | boundary password changed to distinct characters |
| `422 Body is too similar to what you recently posted` | static test data reused across runs | every generated body/subject now carries a unique token |
| infinite waits on the similar-topic dialog | Discourse warns when a title resembles an existing topic | helper dismisses/accepts the dialog before waiting for navigation |
| `429` on `/session` | login rate limit tripped by negative login cases | environment raises `max_logins_per_ip_per_minute`; documented in run instructions |
