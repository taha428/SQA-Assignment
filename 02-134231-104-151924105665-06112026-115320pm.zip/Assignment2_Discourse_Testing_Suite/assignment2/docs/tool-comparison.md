# Tool comparison (Selenium WebDriver vs Playwright)

Same application, same machine, headless Chromium.

| Aspect | Selenium 4.52 | Playwright 1.56 |
|--------|---------------|-----------------|
| Setup | Selenium Manager resolves the driver automatically; Chrome 156 needed no manual driver | one command (`playwright install chromium`), bundled browser |
| Auto-waiting | explicit `WebDriverWait` for every state change | built-in actionability (visible, stable, enabled) before every action |
| Multi-step Ember forms (sign-up/login modal) | synthetic click did not trigger the component action; only `ActionChains`/Enter worked, intermittently | works reliably, including the multi-step modal |
| Cross-context work (two users) | new driver per user, heavier | `browser.new_context()` - cheap, isolated cookies |
| Failure evidence | screenshot + stack trace | screenshot, trace, video, network log |
| Speed (Module A, 4 cases) | ~36 s | ~20 s for the same coverage |

**Conclusion** Playwright is the better fit for this SPA; Selenium remains adequate for
classic form/session checks (login, cookie flags), which is where it is used in Module A.
