"""NFR-01 Performance  |  Owner: Muhammad Raza (02-134231-099)

Requirement (retained from Assignment 1)
    NFR-01  The main page content (topic list) shall become visible and usable
            within about 3 seconds on a standard broadband connection under
            normal load.

Measurable check
    Metric      : p95 latency of GET /latest.json  +  browser DOMContentLoaded
    Threshold   : p95 <= 3000 ms and error rate <= 1 %
    Conditions  : 5 concurrent virtual users for 30 s against the local instance,
                  after a 3-request warm-up; JSON endpoint excludes asset download
                  so the measurement isolates server rendering time.
    Tool        : Python requests (load generation) + Playwright (browser timing)

Results are written to reports/nfr01_performance.json so the report can quote the
measured numbers.
"""
import json
import os
import statistics
import threading
import time

import pytest

import config

DURATION_S = int(os.getenv("NFR01_DURATION", "30"))
CONCURRENCY = int(os.getenv("NFR01_CONCURRENCY", "5"))
THRESHOLD_MS = 3000.0


def _worker(stop_at, latencies, errors, url):
    import requests

    session = requests.Session()
    while time.time() < stop_at:
        start = time.perf_counter()
        try:
            r = session.get(url, timeout=10)
            elapsed = (time.perf_counter() - start) * 1000
            if r.status_code == 200:
                latencies.append(elapsed)
            else:
                errors.append(r.status_code)
        except Exception as exc:  # noqa: BLE001
            errors.append(repr(exc))
        time.sleep(0.05)


@pytest.mark.nfr
def test_nfr01_latest_page_performance(page):
    url = f"{config.BASE_URL}/latest.json"
    import requests

    # Warm-up so JIT/asset caching does not distort the sample.
    for _ in range(3):
        requests.get(url, timeout=10)

    latencies, errors = [], []
    stop_at = time.time() + DURATION_S
    threads = [
        threading.Thread(target=_worker, args=(stop_at, latencies, errors, url))
        for _ in range(CONCURRENCY)
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert latencies, "Load test produced no successful samples"
    ordered = sorted(latencies)
    p50 = statistics.median(ordered)
    p95 = ordered[min(len(ordered) - 1, int(round(0.95 * len(ordered))) - 1)]
    error_rate = len(errors) / (len(latencies) + len(errors))

    # Browser-level measurement of the same requirement.
    page.goto(f"{config.BASE_URL}/latest", wait_until="load", timeout=config.DEFAULT_TIMEOUT_MS)
    nav = page.evaluate("() => { const n = performance.getEntriesByType('navigation')[0];"
                        " return {dcl: n.domContentLoadedEventEnd, load: n.loadEventEnd}; }")

    result = {
        "requirement": "NFR-01",
        "endpoint": url,
        "concurrency": CONCURRENCY,
        "duration_s": DURATION_S,
        "samples": len(latencies),
        "errors": len(errors),
        "error_rate": round(error_rate, 4),
        "p50_ms": round(p50, 1),
        "p95_ms": round(p95, 1),
        "threshold_ms": THRESHOLD_MS,
        "browser_dom_content_loaded_ms": round(nav["dcl"], 1),
        "browser_load_ms": round(nav["load"], 1),
        "verdict": "PASS" if (p95 <= THRESHOLD_MS and error_rate <= 0.01) else "FAIL",
    }
    with open(os.path.join(config.REPORTS_DIR, "nfr01_performance.json"), "w") as fh:
        json.dump(result, fh, indent=2)
    print(json.dumps(result, indent=2))

    assert error_rate <= 0.01, f"Error rate {error_rate:.2%} exceeds the 1% threshold"
    assert p95 <= THRESHOLD_MS, (
        f"p95 latency {p95:.0f} ms exceeds the {THRESHOLD_MS:.0f} ms threshold "
        f"(p50 {p50:.0f} ms, {len(latencies)} samples, {CONCURRENCY} users)"
    )
