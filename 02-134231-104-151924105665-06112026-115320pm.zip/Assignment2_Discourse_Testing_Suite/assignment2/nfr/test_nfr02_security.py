"""NFR-02 Security  |  Owner: Daniyal Jawed (02-134231-085)

Requirement (retained from Assignment 1)
    NFR-02  Passwords shall be stored securely (hashed), accepted only over HTTPS
            and shall meet a minimum length and complexity rule.

Measurable check (three sub-measurements, all must pass)
    M1  Storage      : 100 % of sampled accounts store a PBKDF2-SHA256 hash with
                       >= 100,000 iterations and the hash never equals the plaintext.
                       Threshold: 100 %.  Condition: database read on the local
                       test instance (read-only SQL).
    M2  Session      : the _t session cookie is HttpOnly and SameSite=Lax.
                       Threshold: both flags present on 100 % of logins.
                       Condition: HTTP login against the local instance.
                       (Secure flag is only issued over TLS; the local instance is
                       HTTP by design, which is recorded as an environment note.)
    M3  Policy       : the server-side sign-up endpoint rejects a password below
                       min_password_length (9 characters) with a 4xx response.
                       Threshold: rejected on 100 % of attempts.
                       Condition: POST /u.json with the same payload the UI sends.

Results are written to reports/nfr02_security.json.
"""
import json
import os
import subprocess
import time

import pytest
import requests

import config

REPORT = os.path.join(config.REPORTS_DIR, "nfr02_security.json")


def _db_hashes(usernames: list[str]) -> list[tuple[str, str]]:
    sql = ("SELECT u.username || '|' || p.password_hash FROM users u "
           "JOIN user_passwords p ON p.user_id = u.id WHERE u.username IN (%s)") % ",".join(
        "'" + u.replace("'", "") + "'" for u in usernames
    )
    out = subprocess.run(
        ["psql", "-d", config.PGDATABASE, "-tAc", sql],
        capture_output=True, text=True, timeout=30,
    )
    assert out.returncode == 0, f"Database read failed: {out.stderr[:300]}"
    rows = []
    for line in out.stdout.strip().splitlines():
        if "|" in line:
            rows.append(tuple(line.split("|", 1)))
    return rows


@pytest.mark.nfr
def test_nfr02_password_security():
    result = {"requirement": "NFR-02", "checks": {}, "verdict": "PASS"}

    # ---- M1: storage ---------------------------------------------------------
    users = [config.USERS["daniyal"], config.USERS["raza"], config.USERS["taha"]]
    rows = _db_hashes(users)
    storages = []
    for username, pw_hash in rows:
        ok_prefix = pw_hash.startswith("$pbkdf2-sha256$")
        try:
            iterations = int(pw_hash.split("$")[2])
        except (IndexError, ValueError):
            iterations = 0
        storages.append({
            "username": username,
            "prefix_ok": ok_prefix,
            "iterations": iterations,
            "plaintext": config.FIXTURE_PASSWORD in pw_hash,
        })
    m1_pass = bool(storages) and all(
        s["prefix_ok"] and s["iterations"] >= 100_000 and not s["plaintext"] for s in storages
    )
    result["checks"]["M1_storage"] = {
        "sampled": storages,
        "threshold": "100% PBKDF2-SHA256 with >=100000 iterations",
        "pass": m1_pass,
    }

    # ---- M2: session cookie flags -------------------------------------------
    session = requests.Session()
    csrf = session.get(f"{config.BASE_URL}/session/csrf.json", timeout=15).json()["csrf"]
    resp = session.post(
        f"{config.BASE_URL}/session",
        data={"login": config.USERS["daniyal"], "password": config.FIXTURE_PASSWORD},
        headers={"X-CSRF-Token": csrf, "X-Requested-With": "XMLHttpRequest"},
        timeout=20,
    )
    cookie = next((c for c in session.cookies if c.name == "_t"), None)
    m2_pass = resp.status_code == 200 and cookie is not None and bool(cookie._rest.get("HttpOnly")) and str(
        cookie._rest.get("SameSite", "")
    ).lower() == "lax"
    result["checks"]["M2_session_cookie"] = {
        "status": resp.status_code,
        "http_only": bool(cookie._rest.get("HttpOnly")) if cookie else None,
        "same_site": cookie._rest.get("SameSite") if cookie else None,
        "secure_flag": cookie.secure if cookie else None,
        "note": "Secure flag requires TLS; local instance is intentionally HTTP.",
        "pass": m2_pass,
    }

    # ---- M3: server side password policy -------------------------------------
    fresh = requests.Session()
    csrf2 = fresh.get(f"{config.BASE_URL}/session/csrf.json", timeout=15).json()["csrf"]
    short_pw = "Ab1" + "x" * (config.MIN_PASSWORD_LENGTH - 4)  # length 9
    username = f"qasec{int(time.time() * 1000) % 10**8}"
    signup = fresh.post(
        f"{config.BASE_URL}/u.json",
        data={
            "username": username,
            "email": f"{username}@example.com",
            "password": short_pw,
            "password_confirmation": short_pw,
            "challenge": "",
        },
        headers={"X-CSRF-Token": csrf2, "X-Requested-With": "XMLHttpRequest"},
        timeout=25,
    )
    accepted = signup.status_code == 200 and '"success":true' in signup.text.replace(" ", "")
    result["checks"]["M3_password_policy"] = {
        "password_length": len(short_pw),
        "minimum": config.MIN_PASSWORD_LENGTH,
        "status_code": signup.status_code,
        "response": signup.text[:300],
        "accepted_weak_password": accepted,
        "pass": not accepted,
    }

    failed = [k for k, v in result["checks"].items() if not v["pass"]]
    result["verdict"] = "PASS" if not failed else "FAIL"
    result["failed_checks"] = failed
    with open(REPORT, "w") as fh:
        json.dump(result, fh, indent=2)
    print(json.dumps(result, indent=2))

    assert m1_pass, "Passwords are not stored with a strong PBKDF2 SHA-256 hash"
    assert m2_pass, "Session cookie is missing HttpOnly / SameSite=Lax"
    assert not accepted, (
        "The sign-up API accepted a password shorter than min_password_length - "
        "server-side policy is not enforced (recorded as defect D-01)"
    )
