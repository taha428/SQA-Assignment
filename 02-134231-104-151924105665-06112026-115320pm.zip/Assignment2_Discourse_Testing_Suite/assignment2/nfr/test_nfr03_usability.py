"""NFR-03 Usability and compatibility  |  Owner: Taha Bilal (02-134231-104)

Requirement (retained from Assignment 1)
    NFR-03  The interface shall be usable on desktop and mobile screen sizes, and
            core actions (register, post, search) shall be completable by a new
            user without training.

Measurable check
    Metric      : (a) horizontal overflow in px (scrollWidth - innerWidth)
                  (b) visibility of header, search control and primary navigation
                  (c) height of the primary header controls in px
                  (d) a core action completes (composer opens / search runs)
    Threshold   : overflow <= 2 px at every viewport, all controls visible,
                  primary control height >= 32 px, core action succeeds
    Conditions  : viewports 360x800 (mobile), 768x1024 (tablet), 1440x900 (desktop),
                  one fresh anonymous session per viewport.
    Tool        : Playwright

Results are written to reports/nfr03_usability.json.
"""
import json
import os

import pytest

import config

VIEWPORTS = [
    ("mobile", 360, 800),
    ("tablet", 768, 1024),
    ("desktop", 1440, 900),
]
REPORT = os.path.join(config.REPORTS_DIR, "nfr03_usability.json")


@pytest.mark.nfr
def test_nfr03_responsive_usability(browser):
    results = []
    failed = []

    for name, width, height in VIEWPORTS:
        ctx = browser.new_context(viewport={"width": width, "height": height})
        page = ctx.new_page()
        page.set_default_timeout(config.DEFAULT_TIMEOUT_MS)
        # A core action needs a session: sign in once per viewport.
        from utils.pw import DiscourseUI

        view_ui = DiscourseUI(page)
        view_ui.login(config.USERS["taha"], config.FIXTURE_PASSWORD)
        page.goto(f"{config.BASE_URL}/latest", wait_until="domcontentloaded")
        page.wait_for_timeout(2500)

        metrics = page.evaluate(
            """() => {
                const doc = document.documentElement;
                const header = document.querySelector('header');
                const search = document.querySelector('#search-button');
                const sidebar = document.querySelector('.sidebar-wrapper, .btn-sidebar-toggle, #toggle-hamburger-menu, .hamburger-panel');
                const box = el => el ? el.getBoundingClientRect() : null;
                return {
                    overflow: doc.scrollWidth - window.innerWidth,
                    header_visible: !!header && header.getBoundingClientRect().height > 20,
                    header_height: header ? header.getBoundingClientRect().height : 0,
                    search_visible: !!search && search.getBoundingClientRect().width > 0,
                    search_height: search ? search.getBoundingClientRect().height : 0,
                    nav_visible: !!sidebar && sidebar.getBoundingClientRect().width > 0,
                    body_width: document.body.getBoundingClientRect().width
                };
            }"""
        )

        # Core action: open the composer and confirm the title field is reachable.
        composer_ok = True
        try:
            page.goto(f"{config.BASE_URL}/new-topic", wait_until="domcontentloaded")
            page.wait_for_selector("#reply-title", state="visible", timeout=15000)
            page.locator("#reply-title").fill("Responsive layout probe title")
            composer_ok = True
        except Exception:
            composer_ok = False

        checks = {
            "overflow_ok": metrics["overflow"] <= 2,
            "header_visible": metrics["header_visible"],
            "search_visible": metrics["search_visible"],
            "nav_visible": metrics["nav_visible"],
            "tap_target_ok": metrics["search_height"] >= 32,
            "core_action_ok": composer_ok,
        }
        passed = all(checks.values())
        if not passed:
            failed.append({"viewport": name, "checks": checks})
        results.append({
            "viewport": name,
            "size": f"{width}x{height}",
            "metrics": metrics,
            "checks": checks,
            "pass": passed,
        })
        page.screenshot(path=os.path.join(config.EVIDENCE_DIR, f"NFR-03_{name}_{width}x{height}.png"))
        ctx.close()

    report = {
        "requirement": "NFR-03",
        "threshold": "overflow <= 2px, all controls visible, control height >= 32px, core action completes",
        "viewports": results,
        "verdict": "PASS" if not failed else "FAIL",
        "failed": failed,
    }
    with open(REPORT, "w") as fh:
        json.dump(report, fh, indent=2)
    print(json.dumps(report, indent=2))

    assert not failed, f"Usability checks failed at: {failed}"
