"""Central configuration for the Discourse Assignment 2 automation suite.

All values can be overridden with environment variables so the same suite can
run against a local Docker instance, a college lab VM or the hosted trial site.
"""
import os

# Application under test -----------------------------------------------------
BASE_URL = os.getenv("DISCOURSE_BASE_URL", "http://localhost:4200").rstrip("/")
# Admin key is only used by the load-test fixture and by cleanup helpers.
API_KEY = os.getenv("DISCOURSE_API_KEY", "")
API_USERNAME = os.getenv("DISCOURSE_API_USERNAME", "admin_qa")

# Accounts created by tools/setup_fixtures.rb ---------------------------------
ADMIN_USER = os.getenv("QA_ADMIN_USER", "admin_qa")
ADMIN_PASSWORD = os.getenv("QA_ADMIN_PASSWORD", "Str0ng-Passw0rd!")
FIXTURE_PASSWORD = os.getenv("QA_FIXTURE_PASSWORD", "Str0ng-Passw0rd!")
USERS = {
    "daniyal": os.getenv("QA_USER_M1", "daniyal_qa"),
    "raza": os.getenv("QA_USER_M2", "raza_qa"),
    "taha": os.getenv("QA_USER_M3", "taha_qa"),
    "maria": os.getenv("QA_USER_M4", "maria_qa"),
}
CATEGORY_SLUG = os.getenv("QA_CATEGORY_SLUG", "qa-automation")
CATEGORY_NAME = os.getenv("QA_CATEGORY_NAME", "QA Automation")
SEARCH_MARKER = os.getenv("QA_SEARCH_MARKER", "ZQX2026")

# Mail capture (tools/smtp_sink.py) -------------------------------------------
MAIL_DIR = os.getenv("MAIL_SINK_DIR", "/tmp/qa_mailbox")

# Artefacts -------------------------------------------------------------------
ROOT = os.path.dirname(os.path.abspath(__file__))
EVIDENCE_DIR = os.path.join(ROOT, "evidence")
REPORTS_DIR = os.path.join(ROOT, "reports")
for _d in (EVIDENCE_DIR, REPORTS_DIR):
    os.makedirs(_d, exist_ok=True)

HEADLESS = os.getenv("QA_HEADLESS", "1") != "0"
SLOW_MO_MS = int(os.getenv("QA_SLOW_MO", "0"))
DEFAULT_TIMEOUT_MS = int(os.getenv("QA_TIMEOUT_MS", "30000"))

# Database used by the NFR-02 storage check (local test instance only).
PGDATABASE = os.getenv("PGDATABASE", "discourse_development")

# Site-setting values the suite asserts against (mirrors A1 manual observations)
MIN_PASSWORD_LENGTH = int(os.getenv("QA_MIN_PASSWORD_LENGTH", "10"))
MIN_TITLE_LENGTH = int(os.getenv("QA_MIN_TITLE_LENGTH", "15"))
MIN_POST_LENGTH = int(os.getenv("QA_MIN_POST_LENGTH", "20"))
MIN_SEARCH_LENGTH = int(os.getenv("QA_MIN_SEARCH_LENGTH", "3"))
