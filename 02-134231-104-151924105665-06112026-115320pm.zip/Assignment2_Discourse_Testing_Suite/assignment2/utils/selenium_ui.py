"""Selenium WebDriver helpers (Module A owner: Daniyal Jawed).

The module owner keeps a separate driver stack so the report can compare
Selenium against Playwright for the same application (Assignment 1 did the
same comparison with Taha's module).
"""
from __future__ import annotations

import os

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

import config


def make_driver() -> webdriver.Chrome:
    options = Options()
    if config.HEADLESS:
        options.add_argument("--headless=new")
    options.add_argument("--window-size=1440,1000")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-search-engine-choice-screen")
    driver = webdriver.Chrome(options=options)
    driver.set_window_size(1440, 1000)
    driver.implicitly_wait(0)
    return driver


class SeleniumUI:
    def __init__(self, driver: webdriver.Chrome):
        self.driver = driver
        self.wait = WebDriverWait(driver, config.DEFAULT_TIMEOUT_MS / 1000)

    # ------------------------------------------------------------------ util
    def _click(self, css: str):
        el = self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, css)))
        el.click()
        return el

    def _type(self, css: str, text: str):
        el = self.wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, css)))
        el.clear()
        el.send_keys(text)
        return el

    def _text(self, css: str) -> str:
        el = self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, css)))
        return el.text

    def screenshot(self, name: str) -> str:
        path = os.path.join(config.EVIDENCE_DIR, f"{name}.png")
        try:
            self.driver.save_screenshot(path)
        except Exception:
            return ""
        return path

    # ------------------------------------------------------------------ auth
    def open_home(self):
        self.driver.get(f"{config.BASE_URL}/")
        self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, ".sign-up-button, #current-user")))

    def login(self, username: str, password: str):
        self.open_home()
        if not self.driver.find_elements(By.CSS_SELECTOR, "#current-user"):
            self._click(".login-button")
            self._type("#login-account-name", username)
            self._type("#login-account-password", password)
            import time

            from selenium.webdriver.common.action_chains import ActionChains

            time.sleep(0.5)  # let the component enable the submit control
            ctas = [
                b
                for b in self.driver.find_elements(By.CSS_SELECTOR, ".login-page-cta__login, #login-button")
                if b.is_displayed()
            ]
            assert ctas, "Login submit control not found"
            ActionChains(self.driver).move_to_element(ctas[-1]).pause(0.2).click().perform()
        self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "#current-user")))

    def logged_in(self) -> bool:
        return bool(self.driver.find_elements(By.CSS_SELECTOR, "#current-user"))

    # --------------------------------------------------------------- sign-up
    def open_signup(self):
        self.driver.get(f"{config.BASE_URL}/signup")
        self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, ".signup-page-cta__signup")))
        if not self.driver.find_elements(By.CSS_SELECTOR, "#new-account-username"):
            self._click(".signup-page-cta__signup")
        self.wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, "#new-account-username")))

    def fill_signup(self, username: str, email: str, password: str):
        self._type("#new-account-email", email)
        self._type("#new-account-username", username)
        pw = self._type("#new-account-password", password)
        pw.send_keys(Keys.TAB)  # blur triggers the client-side password validation
        try:
            self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "#password-validation")))
        except Exception:
            pass
        self.driver.implicitly_wait(0)

    def submit_signup(self):
        # The submit control lives outside the <form>; a real pointer click via
        # ActionChains lets Ember's delegated event handler run (WebElement.click()
        # and a JS click are both swallowed by this component in headless Chrome).
        import time

        from selenium.webdriver.common.action_chains import ActionChains

        time.sleep(0.8)
        buttons = [b for b in self.driver.find_elements(By.CSS_SELECTOR, ".signup-page-cta__signup") if b.is_displayed()]
        assert buttons, "Sign-up call-to-action not found"
        ActionChains(self.driver).move_to_element(buttons[-1]).pause(0.3).click().perform()

    def signup_dialog_text(self) -> str:
        try:
            return self.driver.find_element(By.CSS_SELECTOR, ".create-account").text
        except Exception:
            return self.driver.find_element(By.CSS_SELECTOR, "body").text

    def signup_error_messages(self) -> list[str]:
        els = self.driver.find_elements(By.CSS_SELECTOR, ".create-account .form-kit__validation, .create-account .error, .create-account .alert")
        return [e.text.strip() for e in els if e.text.strip()]

    # ---------------------------------------------------------------- others
    @property
    def current_url(self) -> str:
        return self.driver.current_url

    def body_text(self) -> str:
        return self.driver.find_element(By.CSS_SELECTOR, "body").text
