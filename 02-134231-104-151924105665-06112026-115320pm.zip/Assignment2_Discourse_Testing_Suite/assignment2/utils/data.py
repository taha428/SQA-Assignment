"""Deterministic test-data builders.

Every dynamically created record carries a unique suffix so the suite can be
re-run against the same instance without duplicate-name failures.
"""
import random
import string
import time

from config import (
    CATEGORY_NAME,
    MIN_PASSWORD_LENGTH,
    MIN_POST_LENGTH,
    MIN_SEARCH_LENGTH,
    MIN_TITLE_LENGTH,
)

_ALNUM = string.ascii_lowercase + string.digits


def token(length: int = 6) -> str:
    """Short unique token used inside usernames, titles and subjects."""
    return "".join(random.choices(_ALNUM, k=length))


def unique(prefix: str, length: int = 6) -> str:
    return f"{prefix}{int(time.time() * 1000) % 10**7}{token(length)}"[:20]


# --------------------------------------------------------------------------
# Equivalence-partition and boundary-value test data (see docs/TEST_DESIGN.md)
# --------------------------------------------------------------------------
def valid_account(prefix: str = "qaacct") -> dict:
    """Valid partition: username within 3-20, deliverable email, password 12.."""
    user = unique(prefix)
    return {
        "username": user,
        "email": f"{user}@example.com",
        "password": "Str0ng-Passw0rd!",  # 16 chars, above the 10-char minimum
    }


def password_at_minimum() -> str:
    """Boundary value: exactly min_password_length characters.

    The characters are all distinct: Discourse also rejects a password with too
    many repeated characters, which would make the boundary value fail for the
    wrong reason.
    """
    base = "Qa7mZ2kL9vXb4Rt6Yn"
    assert len(base) >= MIN_PASSWORD_LENGTH
    return base[:MIN_PASSWORD_LENGTH]


def password_below_minimum() -> str:
    """Boundary value: min_password_length - 1 characters (invalid)."""
    return password_at_minimum()[:-1]


def title_at_minimum() -> str:
    """Boundary value: exactly min_topic_title_length characters (unique per run)."""
    base = "QAt" + token(5)
    return base.ljust(MIN_TITLE_LENGTH, "z")[:MIN_TITLE_LENGTH]


def title_below_minimum() -> str:
    """Boundary value: min_topic_title_length - 1 characters."""
    return ("Q" * (MIN_TITLE_LENGTH - 1))


def valid_topic() -> dict:
    tag = token(6)
    return {
        "title": f"Automated regression topic {tag} for module B checks",
        # The trailing marker keeps the body unique: Discourse rejects a post whose
        # body is too similar to one posted by the same user recently.
        "body": ("This topic was created by the automated suite to verify that a "
                 f"well formed topic is accepted, stored and listed. Ref {tag}."),
        "category": CATEGORY_NAME,
    }


def valid_reply() -> str:
    return ("Automated reply created by the module B suite to verify the reply "
            f"workflow and the owner notification. Ref {token(6)}.")


def below_min_post_body() -> str:
    return "Too short"


def search_query(term: str) -> str:
    return term


def short_search_term() -> str:
    return "zq"[: MIN_SEARCH_LENGTH - 1]


def valid_search_term(marker: str) -> str:
    return marker[: max(MIN_SEARCH_LENGTH, 3)]


def valid_message() -> dict:
    return {
        "subject": f"Automated PM {token(5)} from the QA suite",
        "body": ("Hello, this private message was sent by the automated suite to "
                 "verify the module C messaging workflow. " * 1).strip(),
    }
