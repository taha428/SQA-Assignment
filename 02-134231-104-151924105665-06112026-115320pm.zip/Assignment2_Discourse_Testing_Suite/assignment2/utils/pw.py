"""Reusable Playwright helpers shared by every module owner.

Keeping the navigation steps here means the four Module B/C cases, the three
NFR checks and the end-to-end test all drive the application the same way, so a
selector fix lands in one place (see docs/REUSE.md).
"""
from __future__ import annotations

import os
import re

from playwright.sync_api import Page, expect

import config


def _shot(page: Page, name: str) -> str:
    path = os.path.join(config.EVIDENCE_DIR, f"{name}.png")
    try:
        page.screenshot(path=path, full_page=False)
    except Exception:  # page may already be closed after a hard failure
        return ""
    return path


class DiscourseUI:
    """Thin page-object wrapper for the flows exercised by the suite."""

    def __init__(self, page: Page):
        self.page = page

    # ------------------------------------------------------------------ auth
    def login(self, username: str, password: str) -> None:
        p = self.page
        for attempt in range(3):
            try:
                p.goto(f"{config.BASE_URL}/login", wait_until="domcontentloaded")
                break
            except Exception:
                if attempt == 2:
                    raise
                p.wait_for_timeout(1500)
        p.wait_for_timeout(800)
        if p.locator("#current-user").count() == 0:
            p.wait_for_selector("#login-account-name", state="visible")
            p.fill("#login-account-name", username)
            p.fill("#login-account-password", password)
            p.wait_for_timeout(400)
            cta = p.locator(".login-page-cta__login:visible, #login-button:visible")
            cta.first.click()
        p.wait_for_selector("#current-user", timeout=config.DEFAULT_TIMEOUT_MS)
        expect(p.locator("#current-user")).to_be_visible()

    def logout(self) -> None:
        p = self.page
        p.goto(f"{config.BASE_URL}/", wait_until="domcontentloaded")
        p.evaluate("""() => {
            const el = document.querySelector('#current-user');
            if (el) el.click();
        }""")
        p.wait_for_timeout(600)
        link = p.locator("a[href$='/logout'], .logout-link, li.logout a")
        if link.count():
            link.first.click()
            p.wait_for_timeout(1500)

    def logged_in(self) -> bool:
        return self.page.locator("#current-user").count() > 0

    # -------------------------------------------------------------- sign-up
    def open_signup_form(self) -> None:
        p = self.page
        p.goto(f"{config.BASE_URL}/signup", wait_until="domcontentloaded")
        p.wait_for_timeout(1200)
        if p.locator("#new-account-username").count() == 0 or not p.locator(
            "#new-account-username"
        ).first.is_visible():
            p.locator(".signup-page-cta__signup").first.click()
        p.wait_for_selector("#new-account-username", state="visible")

    # Alias kept for readability in the test modules.
    def open_signup(self) -> None:
        self.open_signup_form()

    def fill_signup(self, username: str, email: str, password: str) -> None:
        p = self.page
        p.fill("#new-account-email", email)
        p.fill("#new-account-username", username)
        p.fill("#new-account-password", password)
        p.keyboard.press("Tab")  # blur triggers the client-side password validation
        try:
            p.wait_for_function(
                "() => { const e = document.querySelector('#password-validation');"
                " return e && e.innerText.trim().length > 0; }",
                timeout=8000,
            )
        except Exception:
            pass

    def submit_signup(self) -> None:
        p = self.page
        # Wait for the client-side validation and username availability check to
        # settle: the button is disabled until both complete.
        p.locator("#password-validation").first.wait_for(state="visible", timeout=15000)
        btn = p.locator(".signup-page-cta__signup").last
        expect(btn).to_be_enabled(timeout=15000)
        p.wait_for_timeout(400)
        for _ in range(3):
            btn.click()
            p.wait_for_timeout(1500)
            if "/u/account-created" in p.url or p.locator("#password-validation").count() == 0:
                break

    def signup_validation_messages(self) -> str:
        p = self.page
        box = p.locator("#password-validation")
        return box.inner_text() if box.count() else p.locator("body").inner_text()

    def signup(
        self, username: str, email: str, password: str, wait: bool = True
    ) -> None:
        self.open_signup_form()
        self.fill_signup(username, email, password)
        self.submit_signup()
        if wait:
            self.page.wait_for_url(re.compile(r".*/(u/account-created|u/activate-account).*"),
                                   timeout=config.DEFAULT_TIMEOUT_MS)

    def account_created_banner(self) -> str:
        p = self.page
        p.wait_for_timeout(800)
        return p.locator("body").inner_text()

    # -------------------------------------------------------------- topics
    def dismiss_dialogs(self) -> None:
        """Close any blocking modal (validation dialogs, composer error alerts)."""
        p = self.page
        try:
            if p.locator("#dialog-holder .dialog-overlay, .dialog-overlay").count():
                p.keyboard.press("Escape")
                p.wait_for_timeout(600)
        except Exception:
            pass

    def open_new_topic(self) -> None:
        p = self.page
        p.goto(f"{config.BASE_URL}/new-topic", wait_until="domcontentloaded")
        self.dismiss_dialogs()
        p.wait_for_selector("#reply-title", state="visible")

    def select_category(self, name: str) -> None:
        p = self.page
        p.locator(".category-chooser").first.click()
        p.wait_for_selector(".select-kit-body .select-kit-row", state="visible")
        p.locator(f'.select-kit-body .select-kit-row[data-name="{name}"]').first.click()
        p.wait_for_timeout(400)

    def fill_topic(self, title: str, body: str, category: str | None = None) -> None:
        p = self.page
        p.fill("#reply-title", title)
        p.locator(".d-editor-input").first.fill(body)
        if category:
            self.select_category(category)
        p.wait_for_timeout(500)

    def dismiss_similar_topic_dialog(self) -> bool:
        """Discourse warns when a new title resembles an existing topic."""
        p = self.page
        dialog = p.locator("#dialog-holder")
        if dialog.count() and dialog.first.is_visible():
            for pattern in ("Create Topic", "Create", "Post", "Yes", "Continue"):
                btn = p.locator("#dialog-holder button", has_text=pattern)
                if btn.count():
                    btn.first.click()
                    p.wait_for_timeout(900)
                    return True
            p.keyboard.press("Escape")
            p.wait_for_timeout(400)
            return True
        return False

    def submit_topic(self) -> None:
        p = self.page
        for attempt in range(3):
            btn = p.locator("#reply-control button.create:visible, button.create:visible")
            if not btn.count():
                btn = p.get_by_role("button", name=re.compile("Create Topic", re.I))
            btn.last.click()
            p.wait_for_timeout(1200)
            try:
                if p.locator("#dialog-holder").count() and p.locator("#dialog-holder").first.is_visible():
                    self.dismiss_similar_topic_dialog()
                p.wait_for_url(re.compile(r"/t/"), timeout=20000)
                return
            except Exception:
                if attempt == 2:
                    raise
                p.wait_for_timeout(600)

    def composer_error_text(self) -> str:
        p = self.page
        return p.locator("#reply-control").inner_text()

    def reply(self, body: str) -> None:
        p = self.page
        p.locator(".topic-footer-main-buttons button.create").first.click()
        p.wait_for_selector(".d-editor-input", state="visible")
        p.locator(".d-editor-input").first.fill(body)
        p.wait_for_timeout(500)
        for attempt in range(3):
            p.locator("#reply-control button.create").click()
            p.wait_for_timeout(1500)
            if p.locator("#dialog-holder").count() and p.locator("#dialog-holder").first.is_visible():
                self.dismiss_similar_topic_dialog()
            # Composer closes once the post is accepted.
            if p.locator("#reply-control").count() == 0 or not p.locator("#reply-control").first.is_visible():
                return
            if attempt == 2:
                return
        p.wait_for_timeout(500)

    def open_topic(self, url_or_id) -> None:
        target = url_or_id if str(url_or_id).startswith("http") else f"{config.BASE_URL}/t/{url_or_id}"
        self.page.goto(target, wait_until="domcontentloaded")
        self.dismiss_dialogs()
        self.page.wait_for_selector(".topic-post", timeout=config.DEFAULT_TIMEOUT_MS)

    def topic_titles(self) -> list[str]:
        return self.page.locator(".topic-list .main-link a.title, tr.topic-list-item a.raw-topic-link").all_inner_texts()

    # -------------------------------------------------------------- search
    def search(self, term: str) -> None:
        p = self.page
        p.goto(f"{config.BASE_URL}/search", wait_until="domcontentloaded")
        box = p.locator("input[placeholder='Search']").first
        box.wait_for(state="visible")
        box.click()
        p.keyboard.type(term, delay=30)
        p.wait_for_timeout(700)
        p.keyboard.press("Enter")
        p.wait_for_timeout(2500)

    def search_result_count(self) -> int:
        return self.page.locator(".fps-result").count()

    def search_results_text(self) -> str:
        return self.page.locator("#main-outlet").inner_text()

    # ------------------------------------------------------------ messages
    def send_message(self, recipient: str, subject: str, body: str) -> None:
        p = self.page
        p.goto(f"{config.BASE_URL}/new-message", wait_until="domcontentloaded")
        p.wait_for_selector(".user-chooser", state="visible")
        p.locator(".user-chooser").first.click()
        p.wait_for_timeout(600)
        p.locator(".user-chooser input.filter-input, .user-chooser input").first.fill(recipient)
        p.wait_for_timeout(1800)
        row = p.locator(f".user-chooser .select-kit-row[data-name='{recipient}'], .user-chooser .select-kit-row", has_text=recipient)
        if row.count():
            row.first.click()
        else:
            p.keyboard.press("Enter")
        p.wait_for_timeout(800)
        p.fill("#reply-title", subject)
        p.locator(".d-editor-input").first.fill(body)
        p.wait_for_timeout(500)
        p.locator("#reply-control button.create").click()
        p.wait_for_timeout(2500)

    def composer_recipient_text(self) -> str:
        return self.page.locator(".user-chooser").first.inner_text()

    # ------------------------------------------------------------- helpers
    def screenshot(self, name: str) -> str:
        return _shot(self.page, name)
