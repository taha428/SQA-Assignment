"""Reads activation mail captured by tools/smtp_sink.py (local test instance)."""
from __future__ import annotations

import email
import glob
import os
import re
import time
from email import policy

import config

LINK_RE = re.compile(r"https?://[^\s\"'<>]+activate-account[^\s\"'<>]*")


def wait_for_message(recipient: str, timeout: float = 45.0) -> str | None:
    """Return the newest .eml path addressed to `recipient` (or None on timeout)."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        hits = []
        for path in glob.glob(os.path.join(config.MAIL_DIR, "*.eml")):
            try:
                with open(path, "rb") as fh:
                    msg = email.message_from_binary_file(fh, policy=policy.default)
            except Exception:
                continue
            if recipient.lower() in str(msg["To"]).lower():
                hits.append((os.path.getmtime(path), path))
        if hits:
            hits.sort()
            return hits[-1][1]
        time.sleep(0.5)
    return None


def body_of(path: str) -> str:
    with open(path, "rb") as fh:
        msg = email.message_from_binary_file(fh, policy=policy.default)
    if msg.is_multipart():
        parts = []
        for part in msg.walk():
            if part.get_content_type() in ("text/plain", "text/html"):
                try:
                    parts.append(part.get_content())
                except Exception:
                    continue
        return "\n".join(parts)
    return msg.get_content()


def activation_link(recipient: str, timeout: float = 45.0) -> str:
    path = wait_for_message(recipient, timeout=timeout)
    assert path, f"No activation mail captured for {recipient} in {config.MAIL_DIR}"
    text = body_of(path)
    match = LINK_RE.search(text)
    assert match, f"Activation link not found in mail for {recipient}"
    link = match.group(0).rstrip(".").replace("&amp;", "&")
    # The captured mail is produced by the dev instance itself; keep the link on
    # the same host the suite is driving.
    if "localhost" in link or "127.0.0.1" in link:
        link = re.sub(r"https?://[^/]+", config.BASE_URL, link)
    return link
