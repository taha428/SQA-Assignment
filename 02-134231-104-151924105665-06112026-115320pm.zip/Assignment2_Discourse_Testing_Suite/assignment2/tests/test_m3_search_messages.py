"""Module C - Search and private messages  |  Owner: Taha Bilal (02-134231-104)

Covers FR-05 (keyword search) and FR-06 (private message delivery - the new
requirement added in Assignment 2).  Tool: Playwright, with a Selenium
cross-check at the end of this file (Assignment 1 used both tools for this
member's modules).

Techniques applied
------------------
TC-C-01  equivalence partitioning  - valid keyword partition
TC-C-02  boundary value analysis   - query length 2 / 3 around the 3-char minimum
TC-C-03  equivalence partitioning  - valid message partition
TC-C-04  equivalence partitioning  - invalid recipient partition
"""
import pytest
from playwright.sync_api import expect

import config
from utils import data


@pytest.mark.m3
@pytest.mark.functional
class TestModuleCSearchMessages:
    @pytest.mark.smoke
    def test_tc_c_01_search_returns_matching_topic(self, ui):
        """TC-C-01 | FR-05 | Positive | EP (valid keyword).  SMOKE case for Module C."""
        ui.login(config.USERS["taha"], config.FIXTURE_PASSWORD)
        ui.search(config.SEARCH_MARKER)
        ui.screenshot("TC-C-01_search_results")

        assert "/search" in ui.page.url, "Submitting a query must open the search results view"
        assert ui.search_result_count() >= 1, "A keyword that exists in a topic must return at least one result"
        text = ui.search_results_text()
        assert config.SEARCH_MARKER in text, "The result list must show the matching topic"
        assert "1 result" in text or "results" in text.lower(), "Result count summary must be shown"
        # The result links to the matching topic and that topic opens.
        href = ui.page.locator(".fps-result a[href*='/t/']").first.get_attribute("href")
        assert href and "/t/" in href, "A search result must link to its topic"
        ui.open_topic(href if href.startswith("http") else f"{config.BASE_URL}{href}")
        assert config.SEARCH_MARKER in ui.page.content(), "The opened result must be the matching topic"

    def test_tc_c_02_search_term_length_boundary(self, ui):
        """TC-C-02 | FR-05 | Negative/Positive | BVA at the 3-character search minimum."""
        ui.login(config.USERS["taha"], config.FIXTURE_PASSWORD)

        below = "ZQ"  # min_search_term_length - 1
        assert len(below) == config.MIN_SEARCH_LENGTH - 1
        ui.search(below)
        ui.page.wait_for_timeout(1200)
        ui.screenshot("TC-C-02_term_below_boundary")
        assert ui.search_result_count() == 0, (
            f"A {len(below)}-character query is below the {config.MIN_SEARCH_LENGTH}-character minimum "
            "and must not return topic results"
        )

        at_min = "ZQX"  # exactly the minimum, still inside the seeded marker
        assert len(at_min) == config.MIN_SEARCH_LENGTH
        ui.search(at_min)
        ui.page.wait_for_timeout(1200)
        ui.screenshot("TC-C-02_term_at_boundary")
        assert ui.search_result_count() >= 1, (
            "A query of exactly the minimum length must be accepted and return the matching topic"
        )

    def test_tc_c_03_send_private_message_delivered(self, ui, browser):
        """TC-C-03 | FR-06 | Positive | EP (valid message partition)."""
        sender, recipient = config.USERS["daniyal"], config.USERS["taha"]
        message = data.valid_message()
        ui.login(sender, config.FIXTURE_PASSWORD)
        ui.send_message(recipient, message["subject"], message["body"])
        ui.screenshot("TC-C-03_message_sent")

        # The message must appear in the sender's sent list.
        ui.page.goto(f"{config.BASE_URL}/u/{sender}/messages/sent", wait_until="domcontentloaded")
        ui.page.wait_for_timeout(2500)
        sent_text = ui.page.locator("#main-outlet").inner_text()
        ui.screenshot("TC-C-03_sent_list")
        assert message["subject"][:30] in sent_text, (
            "The sent message must be listed in the sender's sent messages, "
            f"list showed: {sent_text[:300]!r}"
        )

        # The recipient must see it in their inbox with an unread marker.
        ctx = browser.new_context(viewport={"width": 1440, "height": 900})
        pg = ctx.new_page()
        from utils.pw import DiscourseUI

        rec_ui = DiscourseUI(pg)
        rec_ui.login(recipient, config.FIXTURE_PASSWORD)
        pg.goto(f"{config.BASE_URL}/u/{recipient}/messages", wait_until="domcontentloaded")
        pg.wait_for_timeout(2000)
        inbox = pg.locator("#main-outlet").inner_text()
        pg.screenshot(path=f"{config.EVIDENCE_DIR}/TC-C-03_recipient_inbox.png")
        assert message["subject"][:35] in inbox, (
            "The private message must appear in the recipient inbox, "
            f"inbox showed: {inbox[:300]!r}"
        )
        ctx.close()

    def test_tc_c_04_message_unknown_recipient_rejected(self, ui):
        """TC-C-04 | FR-06 | Negative | EP (invalid recipient partition)."""
        ui.login(config.USERS["daniyal"], config.FIXTURE_PASSWORD)
        message = data.valid_message()
        ui.page.goto(f"{config.BASE_URL}/new-message", wait_until="domcontentloaded")
        ui.page.wait_for_selector(".user-chooser", state="visible")
        ui.page.locator(".user-chooser").first.click()
        ui.page.wait_for_timeout(500)
        ui.page.locator(".user-chooser input").first.fill("no_such_user_99")
        ui.page.wait_for_timeout(1800)
        ui.page.keyboard.press("Enter")
        ui.page.wait_for_timeout(800)
        ui.page.fill("#reply-title", message["subject"])
        ui.page.locator(".d-editor-input").first.fill(message["body"])
        ui.page.wait_for_timeout(600)
        ui.screenshot("TC-C-04_unknown_recipient")

        send = ui.page.locator("#reply-control button.create")
        blocked = send.is_disabled() or not send.is_enabled()
        if not blocked:
            send.click()
            ui.page.wait_for_timeout(2000)
            blocked = "/t/" not in ui.page.url
        assert blocked, "A message to a non-existent user must not be sent"
        assert "no_such_user_99" in ui.page.content(), (
            "The unknown recipient must remain visible in the invalid recipient field"
        )


@pytest.mark.m3
@pytest.mark.functional
def test_tc_c_01_selenium_cross_check(sel):
    """Tool comparison for TC-C-01: same assertion executed with Selenium.

    Not counted in the 12 functional cases - it exists so the report can compare
    stability and runtime of both tools on the same scenario (as in Assignment 1).
    """
    sel.login(config.USERS["taha"], config.FIXTURE_PASSWORD)
    sel.driver.get(f"{config.BASE_URL}/search?q={config.SEARCH_MARKER}")
    sel.wait.until(lambda d: len(d.find_elements("css selector", ".fps-result")) > 0)
    sel.screenshot("TC-C-01_selenium_cross_check")
    results = sel.driver.find_elements("css selector", ".fps-result")
    assert len(results) >= 1, "Selenium must observe the same search result as Playwright"
