"""Module B - Topics and posting  |  Owner: Muhammad Raza (02-134231-099)

Covers FR-03 (create a topic in a category) and FR-04 (reply to a topic and
notify the topic owner).  Tool: Playwright (Chromium).

Techniques applied
------------------
TC-B-01  equivalence partitioning  - valid topic partition
TC-B-02  boundary value analysis   - title length 14 / 15 around the 15-char minimum
TC-B-03  equivalence partitioning  - valid reply partition, notification side effect
TC-B-04  equivalence partitioning  - invalid (empty) reply partition
"""
import pytest
from playwright.sync_api import expect

import config
from utils import data


@pytest.mark.m2
@pytest.mark.functional
class TestModuleBTopicsPosting:
    @pytest.mark.smoke
    def test_tc_b_01_create_topic_valid(self, ui):
        """TC-B-01 | FR-03 | Positive | EP (valid topic partition).  SMOKE case for Module B."""
        topic = data.valid_topic()
        ui.login(config.USERS["raza"], config.FIXTURE_PASSWORD)
        ui.open_new_topic()
        ui.fill_topic(topic["title"], topic["body"], config.CATEGORY_NAME)
        ui.screenshot("TC-B-01_composer_filled")
        ui.submit_topic()
        ui.page.wait_for_url("**/t/**", timeout=config.DEFAULT_TIMEOUT_MS)

        expect(ui.page.locator(".topic-title h1, #topic-title h1").first).to_contain_text(topic["title"][:40])
        expect(ui.page.locator(".topic-post").first).to_be_visible()
        expect(ui.page.locator(".badge-category__name").first).to_contain_text(config.CATEGORY_NAME)
        ui.screenshot("TC-B-01_topic_created")

        # The new topic must also be listed in its category.
        ui.page.goto(f"{config.BASE_URL}/c/{config.CATEGORY_SLUG}", wait_until="domcontentloaded")
        ui.page.wait_for_timeout(1500)
        assert topic["title"][:40] in ui.page.content(), "Created topic must appear in its category list"

    def test_tc_b_02_title_length_boundary(self, browser):
        """TC-B-02 | FR-03 | Negative/Positive | BVA at the 15-character title minimum."""
        from utils.pw import DiscourseUI

        # Boundary value below the minimum -> composer refuses to create the topic.
        short_title = data.title_below_minimum()
        assert len(short_title) == config.MIN_TITLE_LENGTH - 1
        ctx = browser.new_context(viewport={"width": 1440, "height": 900})
        page = ctx.new_page()
        page.set_default_timeout(config.DEFAULT_TIMEOUT_MS)
        short_ui = DiscourseUI(page)
        short_ui.login(config.USERS["raza"], config.FIXTURE_PASSWORD)
        short_ui.open_new_topic()
        short_ui.fill_topic(short_title, "A body long enough for the minimum post length rule.", config.CATEGORY_NAME)
        page.wait_for_timeout(900)
        create = page.locator("#reply-control button.create")
        blocked = not create.is_enabled()
        page.screenshot(path=f"{config.EVIDENCE_DIR}/TC-B-02_title_below_boundary.png")
        if not blocked:
            create.click()
            page.wait_for_timeout(1500)
            blocked = "/t/" not in page.url
        assert blocked, (
            f"A {len(short_title)}-character title is below the {config.MIN_TITLE_LENGTH}-character "
            "minimum and must not be accepted"
        )
        ctx.close()

        # Boundary value exactly at the minimum -> accepted, in a clean session.
        at_min = data.title_at_minimum()
        assert len(at_min) == config.MIN_TITLE_LENGTH
        ctx2 = browser.new_context(viewport={"width": 1440, "height": 900})
        page2 = ctx2.new_page()
        page2.set_default_timeout(config.DEFAULT_TIMEOUT_MS)
        ok_ui = DiscourseUI(page2)
        ok_ui.login(config.USERS["raza"], config.FIXTURE_PASSWORD)
        ok_ui.open_new_topic()
        ok_ui.fill_topic(at_min, "A body long enough for the minimum post length rule at the boundary.", config.CATEGORY_NAME)
        page2.wait_for_timeout(900)
        ok_ui.submit_topic()
        page2.screenshot(path=f"{config.EVIDENCE_DIR}/TC-B-02_title_at_boundary.png")
        assert at_min[:12] in page2.content(), "A title of exactly the minimum length must be accepted"
        ctx2.close()

    def test_tc_b_03_reply_notifies_topic_owner(self, ui, browser):
        """TC-B-03 | FR-04 | Positive | EP (valid reply partition) + notification side effect."""
        owner, replier = config.USERS["daniyal"], config.USERS["raza"]

        # Owner starts a topic.
        owner_ctx = browser.new_context(viewport={"width": 1440, "height": 900})
        owner_page = owner_ctx.new_page()
        owner_ui = type(ui)(owner_page)
        topic = data.valid_topic()
        owner_ui.login(owner, config.FIXTURE_PASSWORD)
        owner_ui.open_new_topic()
        owner_ui.fill_topic(topic["title"], topic["body"], config.CATEGORY_NAME)
        owner_ui.submit_topic()
        owner_page.wait_for_url("**/t/**", timeout=config.DEFAULT_TIMEOUT_MS)
        topic_url = owner_page.url
        topic_id = topic_url.rstrip("/").split("/")[-1]

        # Replier posts a reply in the same browser session.
        ui.login(replier, config.FIXTURE_PASSWORD)
        ui.open_topic(topic_id)
        before = ui.page.locator(".topic-post").count()
        ui.reply(data.valid_reply())
        try:
            ui.page.wait_for_function(
                "n => document.querySelectorAll('.topic-post').length > n", arg=before, timeout=15000
            )
        except Exception:
            pass
        after = ui.page.locator(".topic-post").count()
        if after == before:
            # The stream may still be catching up; reload once before deciding.
            ui.page.reload(wait_until="domcontentloaded")
            ui.page.wait_for_timeout(2500)
            after = ui.page.locator(".topic-post").count()
        ui.screenshot("TC-B-03_reply_posted")

        assert after == before + 1, f"A reply must add exactly one post ({before} -> {after})"
        assert data.valid_reply()[:40] in ui.page.content(), "The reply text must be rendered in the topic"

        # The owner must see the reply in their notification list.
        owner_page.goto(f"{config.BASE_URL}/u/{owner}/notifications", wait_until="domcontentloaded")
        owner_page.wait_for_timeout(2500)
        notif_text = owner_page.locator("#main-outlet").inner_text()
        owner_page.screenshot(path=f"{config.EVIDENCE_DIR}/TC-B-03_owner_notification.png")
        assert replier in notif_text or "replied" in notif_text.lower(), (
            "The topic owner must receive a notification for the new reply, "
            f"notification page showed: {notif_text[:300]!r}"
        )
        owner_ctx.close()

    def test_tc_b_04_reply_empty_body_rejected(self, ui):
        """TC-B-04 | FR-04 | Negative | EP (invalid empty-body partition)."""
        ui.login(config.USERS["raza"], config.FIXTURE_PASSWORD)
        # Create a topic of our own so the negative reply cannot disturb anyone.
        topic = data.valid_topic()
        ui.open_new_topic()
        ui.fill_topic(topic["title"], topic["body"], config.CATEGORY_NAME)
        ui.submit_topic()
        before = ui.page.locator(".topic-post").count()
        assert before >= 1, "Topic creation must succeed before the negative reply check"

        ui.page.locator(".topic-footer-main-buttons button.create").first.click()
        ui.page.wait_for_selector(".d-editor-input", state="visible")
        ui.page.locator(".d-editor-input").first.fill("")
        ui.page.wait_for_timeout(900)
        create = ui.page.locator("#reply-control button.create")
        ui.screenshot("TC-B-04_empty_reply")
        if create.is_enabled():
            create.click()
            ui.page.wait_for_timeout(1500)

        after = ui.page.locator(".topic-post").count()
        assert after == before, f"An empty reply must not create a post ({before} -> {after})"
