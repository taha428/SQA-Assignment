"""Module A - Registration and login  |  Owner: Daniyal Jawed (02-134231-085)

Covers FR-01 (registration with e-mail activation) and FR-02 (login / logout).

Tool split (documented in docs/TOOL_COMPARISON.md)
    TC-A-01, TC-A-02  Playwright  - the multi-step signup component is driven
                                    reliably only through Playwright's actionability
                                    checks; Selenium's synthetic click did not fire
                                    the Ember action consistently in headless Chrome.
    TC-A-03, TC-A-04  Selenium    - login, session cookie and negative credential
                                    checks (the owner's primary tool).

Techniques applied
------------------
TC-A-01  equivalence partitioning  - valid partition of (username, email, password)
TC-A-02  boundary value analysis   - password length 9 / 10 around the 10-char minimum
TC-A-03  equivalence partitioning  - valid credential partition (existing account)
TC-A-04  equivalence partitioning  - invalid credential partitions (wrong password AND
                                     unknown username), both must fail identically
"""
import pytest
from playwright.sync_api import expect

import config
from utils import data


@pytest.mark.m1
@pytest.mark.functional
class TestModuleARegistrationLogin:
    def test_tc_a_01_register_valid_account(self, ui):
        """TC-A-01 | FR-01 | Positive | EP (valid partition)."""
        account = data.valid_account("qaep")
        ui.open_signup()
        ui.fill_signup(account["username"], account["email"], account["password"])
        ui.screenshot("TC-A-01_signup_filled")
        ui.submit_signup()
        ui.page.wait_for_url("**/u/account-created", timeout=config.DEFAULT_TIMEOUT_MS)
        ui.page.wait_for_timeout(800)
        page_text = ui.page.locator("body").inner_text()
        ui.screenshot("TC-A-01_account_created")

        assert "/u/account-created" in ui.page.url, (
            "Registration with a valid partition should land on the account-created page, "
            f"actual URL: {ui.page.url}"
        )
        assert account["email"] in page_text, "Confirmation page must name the e-mail address used"
        assert "activation" in page_text.lower(), "Confirmation page must mention the activation e-mail"
        assert not ui.logged_in(), "A brand-new account must not be logged in before activation"

    def test_tc_a_02_password_length_boundary(self, browser):
        """TC-A-02 | FR-01 | Negative/Positive | BVA at the 10-character password minimum."""
        # Boundary value just below the minimum -> must be rejected.
        below = data.password_below_minimum()
        assert len(below) == config.MIN_PASSWORD_LENGTH - 1
        short_account = data.valid_account("qabva")

        ctx = browser.new_context(viewport={"width": 1440, "height": 900})
        page = ctx.new_page()
        page.set_default_timeout(config.DEFAULT_TIMEOUT_MS)
        from utils.pw import DiscourseUI

        short_ui = DiscourseUI(page)
        short_ui.open_signup()
        short_ui.fill_signup(short_account["username"], short_account["email"], below)
        page.wait_for_timeout(900)
        tip = page.locator("#password-validation")
        tip_text = tip.inner_text() if tip.count() else page.locator("body").inner_text()
        page.screenshot(path=f"{config.EVIDENCE_DIR}/TC-A-02_password_below_boundary.png")
        assert "too short" in tip_text.lower() or str(config.MIN_PASSWORD_LENGTH) in tip_text, (
            f"A {len(below)}-character password must be rejected with a length message, got: {tip_text[:300]!r}"
        )
        short_ui.submit_signup()
        page.wait_for_timeout(1500)
        assert "/u/account-created" not in page.url, "The below-boundary password must not create an account"
        assert not short_ui.logged_in(), "No session may be created for a rejected registration"
        ctx.close()

        # Boundary value exactly at the minimum -> must be accepted.
        at_min = data.password_at_minimum()
        assert len(at_min) == config.MIN_PASSWORD_LENGTH
        at_account = data.valid_account("qabva")
        ctx2 = browser.new_context(viewport={"width": 1440, "height": 900})
        page2 = ctx2.new_page()
        page2.set_default_timeout(config.DEFAULT_TIMEOUT_MS)
        ok_ui = DiscourseUI(page2)
        ok_ui.open_signup()
        ok_ui.fill_signup(at_account["username"], at_account["email"], at_min)
        page2.wait_for_timeout(900)
        ok_ui.submit_signup()
        page2.wait_for_url("**/u/account-created", timeout=config.DEFAULT_TIMEOUT_MS)
        page2.screenshot(path=f"{config.EVIDENCE_DIR}/TC-A-02_password_at_boundary.png")
        assert "/u/account-created" in page2.url, (
            "A password of exactly the minimum length must be accepted (boundary value)"
        )
        ctx2.close()

    @pytest.mark.smoke
    def test_tc_a_03_login_with_valid_credentials(self, sel):
        """TC-A-03 | FR-02 | Positive | EP (valid credential partition).  SMOKE case for Module A."""
        sel.login(config.USERS["daniyal"], config.FIXTURE_PASSWORD)
        sel.screenshot("TC-A-03_logged_in")

        assert sel.logged_in(), "A valid login must expose the current-user header menu"
        header = sel.driver.find_element("css selector", "header").text
        assert "Log In" not in header, "The header must stop offering 'Log In' once authenticated"
        cookies = {c["name"]: c for c in sel.driver.get_cookies()}
        assert "_t" in cookies, "Discourse must set the _t session cookie after login"
        assert cookies["_t"]["httpOnly"] is True, "Session cookie must be HttpOnly"

    def test_tc_a_04_login_with_invalid_credentials(self, sel):
        """TC-A-04 | FR-02 | Negative | EP (two invalid credential partitions)."""
        # Invalid partition 1: existing username, wrong password.
        sel.open_home()
        sel.driver.find_element("css selector", ".login-button").click()
        sel.wait.until(lambda d: d.find_element("css selector", "#login-account-name").is_displayed())
        sel.driver.find_element("css selector", "#login-account-name").send_keys(config.USERS["daniyal"])
        sel.driver.find_element("css selector", "#login-account-password").send_keys("Wrong-Password-123")
        sel.driver.find_element("css selector", "#login-button").click()
        sel.wait.until(lambda d: "Invalid" in d.find_element("css selector", "body").text
                       or "incorrect" in d.find_element("css selector", "body").text.lower())
        first_error = sel.body_text()
        sel.screenshot("TC-A-04_wrong_password")

        assert not sel.logged_in(), "A wrong password must never create a session"
        assert "invalid" in first_error.lower() or "incorrect" in first_error.lower(), (
            "A failed login must explain that the credentials were not accepted"
        )

        # Invalid partition 2: username that does not exist.
        sel.driver.get(f"{config.BASE_URL}/")
        sel.driver.find_element("css selector", ".login-button").click()
        sel.wait.until(lambda d: d.find_element("css selector", "#login-account-name").is_displayed())
        sel.driver.find_element("css selector", "#login-account-name").send_keys("no_such_user_zz9")
        sel.driver.find_element("css selector", "#login-account-password").send_keys(config.FIXTURE_PASSWORD)
        sel.driver.find_element("css selector", "#login-button").click()
        sel.wait.until(lambda d: "Invalid" in d.find_element("css selector", "body").text
                       or "incorrect" in d.find_element("css selector", "body").text.lower())
        sel.screenshot("TC-A-04_unknown_user")
        assert not sel.logged_in(), "An unknown username must never create a session"
